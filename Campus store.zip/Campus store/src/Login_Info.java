public class Login_Info {
    private String admin_username="admin";
    private String admin_password="admin";
    private String employee_username="joy";
    private String employee_password="joy";
    String getAdmin_username(){
        return admin_username;
    }
    String getAdmin_password(){
        return admin_password;
    }
    String getEmployee_username(){
        return employee_username;
    }
    String getEmployee_password(){
        return employee_password;
    }
}
